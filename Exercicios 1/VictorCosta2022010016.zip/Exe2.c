/*  Nome: Victor Hugo Souza Costa 
Matricula: 2022010016

2.Escreva um programa que leia um número 
inteiro e depois o imprima. */

#include<stdio.h>


int main(void)
{
    int num1;
    printf("Digite um numero: "); //Apenas apresentativo.
    scanf("%d",&num1); //Entrada do numero.
    printf("O numero escrito e: %d",num1); //Print final.
    return 0;
}
