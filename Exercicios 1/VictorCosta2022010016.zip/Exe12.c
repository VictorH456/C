/* Nome: Victor Hugo Souza Costa 
Matricula: 2022010016

12.Elabore um programa que contenha uma constante qualquer do tipo int. Use o
comando const. Imprima essa constante.
*/

const int valor = 10; //Outra forma de criar uma constante, só que aqui eu consigo printar diretamente.
#include<stdio.h>

int main()
{
    printf("O valor e: %d",valor); //Print final mostrando os resultados
    return 0;
}