/* Nome: Victor Hugo Souza Costa 
Matricula: 2022010016

1. Elabore um programa que escreva as mensagens "Inicio do programa" e “Fim” na
tela, uma em cada linha, usando apenas um comando printf()*/

#include<stdio.h>

int main(void)
{
    printf("Inicio do Programa\nFim"); //Print simples.
    return 0;
}