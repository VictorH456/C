// Nome: Victor Hugo Souza Costa 
// Matricula: 2022010016
/*Faça um programa que calcule e mostre a soma dos 50 primeiros números pares.*/

#include<stdio.h>

int main()
{
    int soma;
    
    soma = (0 + (0 + (50-1) * 2) ) * 50 / 2 ; //Formula pa(progressão aritmetica)

    printf("%d",soma);

    return 0;
}